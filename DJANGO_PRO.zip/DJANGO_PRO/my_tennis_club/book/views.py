from django.http import HttpResponse
from django.template import loader
from .models import Book,Room,Reservation
from django.shortcuts import render,redirect
from .models import Room, Reservation
from .forms import ReservationForm

def members(request):
  mymembers = Book.objects.all().values()
  template = loader.get_template('all.html')
  context = {
    'mymembers': mymembers,
  }
  return HttpResponse(template.render(context, request))


def details(request, id):
  mymember = Book.objects.get(id=id)
  template = loader.get_template('details.html')
  context = {
    'mymember': mymember,
    'newname' :'jj',
  }
 
  return HttpResponse(template.render(context, request))

def testing(request):
  template = loader.get_template('child.html')
  return HttpResponse(template.render())
  

def home(request):
  template = loader.get_template('base.html')
  return HttpResponse(template.render())

def room_list(request):
    rooms = Room.objects.all()
    return render(request, 'room_list.html', {'rooms': rooms})

def make_reservation(request):
    if request.method == 'POST':
        form = ReservationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('room_list')
    else:
        form = ReservationForm()

    rooms = Room.objects.all()
    return render(request, 'reservation_form.html', {'form': form, 'rooms': rooms})
  