from django.db import models

# Create your models here.
class Book(models.Model):
     firstname = models.CharField(max_length=255)
     lastname = models.CharField(max_length=255)
     phone = models.IntegerField(null=True)
     joined_date = models.DateField(null=True)
    
     def __str__(self):
          return f"{self.firstname}{self.lastname}  {self.phone}  {self.joined_date}"


class Room(models.Model):
    room_number = models.IntegerField(unique=True)
    capacity = models.IntegerField()
    price = models.DecimalField(max_digits=8, decimal_places=2)

    def __str__(self):
        return f"Room {self.room_number}"

class Reservation(models.Model):
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    guest_name = models.CharField(max_length=100)
    check_in_date = models.DateField()
    check_out_date = models.DateField()

    def __str__(self):
        return f"Reservation for {self.guest_name} - Room {self.room.room_number}"
    



    