from django.urls import path
from . import views
from .views import room_list, make_reservation

urlpatterns = [
    path('mem/', views.members, name='mem'),
    path('book_details/<int:id>', views.details, name='details'),
    path('tags/',views.testing, name='testing'),
    path('home',views.home,name="home"),
    path('rooms/', views.room_list, name='room_list'),
    path('make-reservation/', views.make_reservation, name='make_reservation'),
]