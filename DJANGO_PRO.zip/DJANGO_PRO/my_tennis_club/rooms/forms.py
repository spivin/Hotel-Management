from django import forms
from .models import Room
from .models import Guest,Booking,InventoryItem

class RoomForm(forms.ModelForm):
    class Meta:
        model = Room
        fields = ['room_number', 'room_type', 'description', 'capacity', 'rate', 'status']

class GuestForm(forms.ModelForm):
     class Meta:
        model = Guest
        fields = ['first_name', 'last_name', 'email', 'phone_number', 'identification_number']

class BookingForm(forms.ModelForm):
    class Meta:
        model = Booking
        fields = ['guest', 'room', 'check_in_date', 'check_out_date']
    

class InventoryItemForm(forms.ModelForm):
     class Meta:
         model= InventoryItem
         fields=[]