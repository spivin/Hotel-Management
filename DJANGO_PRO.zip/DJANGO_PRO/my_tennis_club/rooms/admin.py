from django.contrib import admin
from .models import Room,Guest,Booking,InventoryItem

admin.site.register(Room)
admin.site.register(Guest)
admin.site.register(Booking)
admin.site.register(InventoryItem)