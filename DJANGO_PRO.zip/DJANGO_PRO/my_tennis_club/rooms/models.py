from django.db import models
# from rooms.models import Room
# from datetime import datetime
# from rooms.models import Guest


class Room(models.Model):
    ROOM_TYPES = (
        ('Single', 'Single'),
        ('Double', 'Double'),
        ('Suite', 'Suite'),
    )
    
    room_number = models.CharField(max_length=10, unique=True)
    room_type = models.CharField(max_length=10, choices=ROOM_TYPES)
    description = models.TextField(blank=True)
    capacity = models.IntegerField(default=1)
    rate = models.DecimalField(max_digits=8, decimal_places=2)
    status = models.CharField(max_length=20, default='Available')
    
    def __str__(self):
        return f"{self.room_number} - {self.room_type}"

class Guest(models.Model):
    first_name=models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(unique=True)
    phone_number = models.CharField(max_length=15)
    identification_number = models.CharField(max_length=20)
    
    def __str__(self):
        return f"{self.first_name} - {self.last_name}"
    

class Booking(models.Model):
    guest = models.ForeignKey(Guest, on_delete=models.CASCADE)
    room = models.ForeignKey(Room, on_delete=models.CASCADE)
    check_in_date = models.DateField()
    check_out_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Booking for {self.guest} - Room {self.room}"

    def duration(self):
        return (self.check_out_date - self.check_in_date).days


class InventoryItem(models.Model):
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    quantity = models.IntegerField(default=0)
   

    def __str__(self):
        return self.name