from django.urls import path
from . import views

urlpatterns = [
    path('v/', views.room_list, name='room_list'),
    path('<str:room_number>/', views.room_detail, name='room_detail'),
    path('create/', views.room_create, name='room_create'),
    path('<str:room_number>/update/', views.room_update, name='room_update'),
    path('<str:room_number>/delete/', views.room_delete, name='room_delete'),
    # guest
     path('g/', views.guest_list, name='guest_list'),
    path('<int:guest_id>/', views.guest_detail, name='guest_detail'),
    path('create/', views.guest_create, name='guest_create'),
    path('<int:guest_id>/update/', views.guest_update, name='guest_update'),
    path('<int:guest_id>/delete/', views.guest_delete, name='guest_delete'),
    # booking

    path('b/', views.booking_list, name='booking_list'),
    path('<int:booking_id>/', views.booking_detail, name='booking_detail'),
    path('create/', views.booking_create, name='booking_create'),
    path('<int:booking_id>/update/', views.booking_update, name='booking_update'),
    path('<int:booking_id>/delete/', views.booking_delete, name='booking_delete'),
    path('i/', views.inventory_list, name='inventory_list'),
    path('<int:item_id>/', views.inventory_detail, name='inventory_detail'),
    path('create/', views.inventory_create, name='inventory_create'),
    path('<int:item_id>/update/', views.inventory_update, name='inventory_update'),
    path('<int:item_id>/delete/', views.inventory_delete, name='inventory_delete'),
]
