from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.

def Home(request):
   template = loader.get_template('myfirst.html')
   return HttpResponse(template.render())
def Contact(request):
    return HttpResponse("<center><h1><table><tr><th>Name</th><th>mail</th></tr></table> </h1></center>")